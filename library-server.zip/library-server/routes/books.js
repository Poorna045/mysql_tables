var Book = require('../models/Book');

exports.search_books = function (req, res) {
    Book.search_books(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.reserve_book = function (req, res) {
    Book.reserve_book(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.my_books = function (req, res) {
    Book.my_books(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.cancel_reservation = function (req, res) {
    Book.cancel_reservation(req.body, (data) => {
        res.status(200).send(data)
    });
}

// Cron cancel reservations
exports.cron_cancel_reservation = function (req, res) {
    Book.cancel_reservation(req.query, (data) => {
        res.status(200).send(data)
    });
}

// Cron due reminder
exports.cron_due_reminder = function (req, res) {
    Book.due_reminder((data) => {
        res.status(200).send(data)
    });
}

// Admin functions
exports.issue_book = function (req, res) {
    if (req.decoded.role != 'admin') {
        res.status(500).send({
            success: false,
            error: 'Unauthorized'
        });
        return;
    }
    Book.issue_book(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.return_book = function (req, res) {
    if (req.decoded.role != 'admin') {
        res.status(500).send({
            success: false,
            error: 'Unauthorized'
        });
        return;
    }
    Book.return_book(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.admin_dashboard = function (req, res) {
    if (req.decoded.role != 'admin') {
        res.status(500).send({
            success: false,
            error: 'Unauthorized'
        });
        return;
    }
    Book.admin_dashboard(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.user_dashboard = function (req, res) {
    if (req.decoded.role != 'user') {
        res.status(500).send({
            success: false,
            error: 'Unauthorized'
        });
        return;
    }
    Book.user_dashboard(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.addnewbook = function (req, res) {
    if (req.decoded.role != 'admin') {
        res.status(500).send({
            success: false,
            error: 'Unauthorized'
        });
        return;
    }
    Book.addnewbook(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.bookdetails = function (req, res) {
    Book.bookdetails(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.requiest = function (req, res) {
    Book.requiest(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.edit = function (req, res) {
    Book.edit(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.update = function (req, res) {
    Book.update(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.delete = function (req, res) {
    Book.delete(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.requestdelete = function (req, res){
    Book.requestdelete(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.check_book = function (req, res) {
    Book.check_book(req.body, (data) => {
        res.status(200).send(data)
    });
}    
exports.bookid = function (req, res) {
    Book.bookid(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.reservebook = function (req, res) {
    Book.reservebook(req.body, (data) => {
        res.status(200).send(data)
    });
}

exports.fine = function (req, res) {
    Book.fine(req.body, (data) => {
        res.status(200).send(data)
    });
}


// module.exports = Book;