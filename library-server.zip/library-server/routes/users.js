var User = require('../models/User');

// Login
exports.login = function (req, res) {
  let reg_no = req.body.reg_no;
  let password = req.body.password;

  if (reg_no && password) {
    User.login(req.body, (data) => {
      res.status(200).send(data)
    });
  } else {
    res.status(500).send({
      success: false,
      error: 'Registration number and password are mandatory'
    })
  } 
}

// Registration
exports.register = function (req, res) {

  console.log("req is", req.body);

  User.register(req.body, (data) => {
    res.status(200).send(data)
  });
}

exports.profile = function (req, res) {

  User.profile(req.body, (data) => {
    res.status(200).send(data)
  });
}

exports.forget_password = function(req, res) {
  User.forget_password(req.body, (data) => {
    res.status(200).send(data)
  });
}


// var express = require('express');
// var router = express.Router();
// var User = require('../models/User');


// /* GET users listing. */
// // router.get('/', function(req, res, next) {
// //   res.send('respond with a resource');
// // });

// router.post('/', function (req, res, next) {
//   let mobile = req.body.mobile;
//   let password = req.body.password;

//   console.log(req.body);

//   if (mobile && password) {
//     let data = User.login(req.body, (data) => {
//       res.status(200).send (data)
//     });

//   } else {
//     let data = {status: false, data: 'Mobile and Password not sent'};
//     res.status(200).send (data);
//   }

//     // if (req.params.id) {
//     //     Issue.getIssue(req.params.id, function (err, rows) {
//     //         if (err) {
//     //             this.data = {
//     //                 success: false,
//     //                 error: err
//     //             }
//     //         } else {
//     //             this.data = {
//     //                 success: true,
//     //                 data: rows
//     //             }

//     //         }
//     //         res.json(this.data);
//     //     });
//     // } 
// });

// module.exports = router;