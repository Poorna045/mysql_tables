// var jwt = require('jsonwebtoken');
// var config = require('../config');
var db = require("../db");
// var log = require('./Log');
// var env = require('dotenv');

var Book = {
  // book search
  search_books: function(data, callback) {
    let searchTerm = data["search_term"].toString();
    searchTerm = searchTerm.replace(" ", "%");

    let sql = "";

    if (searchTerm) {
      // sql = `select distinct title, call_no from books where title like '%${searchTerm}%' or author like '%${searchTerm}%' limit 30`;

      sql = `SELECT *, count(call_no) as count FROM books where title like '%${searchTerm}%' or author like '%${searchTerm}%' group by call_no having acc_no not in (select acc_no from issued where status = 'issued') order by count desc limit 30`;

      db.query(sql, (err, rows) => {
        if (err) throw err;
        if (rows.length) {
          callback({
            success: true,
            rowcount: rows.length,
            data: rows
          });
        } else {
          callback({
            success: true,
            rowcount: rows.length,
            data: rows
          });
        }
      });
    } else {
      callback({
        success: false,
        error: "No query sent"
      });
    }
  },

  // reserve book
  reserve_book: function(data, callback) {
    let acc_no = data["acc_no"];
    let user_id = data["user_id"];
    let status = "reserved";
    let role = data["user_type"]; 
    let sql = "";


    if (acc_no && user_id && status) {
      check=`select * from issued where acc_no='${acc_no}' and (status='issued' or status='reserved')`;
      db.query(check, (err, results) => {
        if(err) throw err;
        else if(results.length==0){
          count=`SELECT * FROM issued WHERE user_id='${user_id}' and (status='issued' or status='reserved')`;
          db.query(count, (err, results) => {
          if(err)	{ throw err; }
          else{
            console.log( results.length,'-------->row values' );
          if((results.length < 3 && role=='user')||(results.length < 5 && role=='faculty')){

          sql = `INSERT INTO issued(acc_no, user_id, reserve_dt, status) values('${acc_no}', '${user_id}', now(), '${status}')`;
          db.query(sql, (err, results) => {
          if(err){
            callback({
              success: false,
              error: err.message
            });
            return;
            }
           else if(results.insertId){
              callback({
                success: true,
                id: results.insertId
              });
            }
            else{
              callback({
                success: false,
                error: `Couldn't reserve book` });
            }
          }); 
        }
         else {
        callback({
          success: false,
          error: `You had taken maximum number of books`
        });
      }
        
      }
    });
          }
        else {
        callback({
          success: false,
          error: `You had taken maximum number of books`
        });
      }
  });
    }
     else {
        callback({
          success: false,
          error: `You had taken maximum number of books`
        });
      }
  },

  // issue book
  issue_book: function(data, callback) {
    let acc_no = data["acc_no"];
    let user_id = data["user_id"];
    let due_days = data["due_days"];
    let status = "issued";
    let sql = "";

    if (acc_no && user_id && status) {
      // sql = `select distinct title, call_no from books where title like '%${searchTerm}%' or author like '%${searchTerm}%' limit 30`;

      sql = `UPDATE issued set status = '${status}', issue_dt = now(), tentative_return_dt = date_add(issue_dt, interval ${due_days} day) where acc_no = ${acc_no} and user_id = ${user_id} limit 1`;

      console.log(sql);

      db.query(sql, (err, results) => {
        if (err) {
          callback({
            success: false,
            error: err.message
          });
          return;
        }
        console.log(results);

        if (results.affectedRows) {
          callback({
            success: true,
            rowcount: results.affectedRows
          });
        } else {
          callback({
            success: false,
            error: `Couldn't reserve book`
          });
        }
      });
    } else {
      callback({
        success: false,
        error: `Couldn't reserve book, please try again later`
      });
    }
  },

  // return book
  return_book: function(data, callback) {
    let acc_no = data["acc_no"];
    let user_id = data["user_id"];
    let status = "returned";
    let sql = "";

    if (acc_no && user_id && status) {
      // sql = `select distinct title, call_no from books where title like '%${searchTerm}%' or author like '%${searchTerm}%' limit 30`;

      sql = `UPDATE issued set status = '${status}', return_dt = now() where acc_no = ${acc_no} and user_id = ${user_id} and status = 'issued' limit 1`;

      console.log(sql);

      db.query(sql, (err, results) => {
        if (err) {
          callback({
            success: false,
            error: err.message
          });
          return;
        }
        console.log(results);

        if (results.affectedRows) {
          callback({
            success: true,
            rowcount: results.affectedRows
          });
        } else {
          callback({
            success: false,
            error: `Couldn't reserve book`
          });
        }
      });
    } else {
      callback({
        success: false,
        error: `Couldn't reserve book, please try again later`
      });
    }
  },

  // Display Books reserved/issued to a user
//   my_books: function(data, callback) {
//     let user_id = data["user_id"];
//     let search_type = data["search_type"];
//     let reg_no = data["reg_no"];
//     let acc_no = data["acc_no"];                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            ["acc_no"];
//     // let email = data['email'];

//     if (!search_type) {
//       search_type = "self";
//     }

//     let sql = "";

//     // sql = `select distinct title, call_no from books where title like '%${searchTerm}%' or author like '%${searchTerm}%' limit 30`;

//     if (search_type == "self") {
//      //sql= `select * from issued`;
//       sql = `select issued.*, books.call_no, books.title, books.author, user.reg_no as user, tentative_return_dt  from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id where issued.user_id = ${user_id} and issued.status != 'returned' order by issue_dt, reserve_dt`;
//     } else {
//       if (reg_no) {
//         // admin search by user
// //        sql = `select issued.acc_no, issued.user_id, title, author, status, date(issue_dt) as issue_dt, books.call_no, books.title, books.author,user.name as user_name, user.reg_no as user_regno,  tentative_return_dt, if (status = 'issued', datediff(tentative_return_dt, now()), '' ) as overdue from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id  where user.reg_no like '%${reg_no}%' and status != 'returned' order by overdue`;
//         sql = `select issued.*, books.call_no, books.title, books.author, user.name as user_name, user.reg_no as user_regno from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id where date(issued.reserve_dt) = date(now()) and issued.user_id = user.user_id and (user.reg_no like '${reg_no}%' or user.name like '${reg_no}%') order by issue_dt, reserve_dt`; 
//       } else if(acc_no){
//         sql=`select * from books where acc_no='${acc_no}'`;
//       } else {
//         // default listing for admin
//       //sql= `select * from issued`;
//         sql = `select issued.*, books.call_no, books.title, books.author, user.name as user_name, user.reg_no as user_regno from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id where date(issued.reserve_dt) = date(now()) and issued.status = 'reserved' order by issue_dt, reserve_dt`;
//       }
//     }

//     console.log(sql);

//     db.query(sql, (err, rows) => {
//       if (err) {
//         callback({
//           success: false,
//           error: `Couldn't retrieve book list, please try again later` +
//             err.message
//         });
//       }else{
//       callback({
//         success: true,
//         rowcount: rows.length,
//         data: rows
//       });}
//     });
//   },


my_books: function(data, callback) {
    let user_id = data["user_id"];
    let search_type = data["search_type"];
    let reg_no = data["reg_no"];
    // let email = data['email'];

    if (!search_type) {
      search_type = "self";
    }

    let sql = "";

    // sql = `select distinct title, call_no from books where title like '%${searchTerm}%' or author like '%${searchTerm}%' limit 30`;

    if (search_type == "self") {
      sql = `select issued.*, books.call_no, books.title, books.author, user.reg_no as user, tentative_return_dt  from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id where issued.user_id = ${user_id} and status != 'returned' order by issue_dt, reserve_dt`;
    } else {
      if (reg_no) {
        // admin search by user
        sql = `select issued.acc_no, issued.user_id, title, author, status, date(issue_dt) as issue_dt, books.call_no, books.title, books.author,user.name as user_name, user.reg_no as user_regno,  tentative_return_dt, if (status = 'issued', datediff(tentative_return_dt, now()), '' ) as overdue from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id  where user.reg_no like '%${reg_no}%' and status != 'returned' order by overdue`;
      } else {
        // default listing for admin
        sql = `select issued.*, books.call_no, books.title, books.author, user.name as user_name, user.reg_no as user_regno from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id where date(issued.reserve_dt) = date(now()) and issued.status = 'reserved' order by issue_dt, reserve_dt`;
    //    sql = `select issued.*, books.call_no, books.title, books.author, user.name as user_name, user.reg_no as user_regno from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id where date(issued.reserve_dt) = date(now()) and issued.status = 'reserved' order by issue_dt, reserve_dt`;  
    }
    }

    console.log(sql);

    db.query(sql, (err, rows) => {
      if (err) {
        callback({
          success: false,
          error: `Couldn't retrieve book list, please try again later` +
            err.message
        });
      }else{
      callback({
        success: true,
        rowcount: rows.length,
        data: rows
      });}
    });
  },

  // Cancel Reservation
  cancel_reservation: function(data, callback) {
    let type = data["type"];
    let user_id = data["user_id"];
    let acc_no = data["acc_no"];
    let sql = "";

    if (type == "cron") {
      sql = `delete from issued where status = 'reserved' `;
    }

    if (user_id && acc_no) {
      sql = `delete from issued where user_id = ${user_id} and acc_no = ${acc_no} and status = 'reserved'`;
    }

    if (sql != "") {
      db.query(sql, (err, rows) => {
        if (err) throw err;
        callback({
          success: true,
          rowcount: rows.length,
          data: rows
        });
      });
    } else {
      callback({
        success: false,
        error: `Server error` + data
      });
    }
  },

  due_reminder: function(callback) {
    const sql = `SELECT books.title, user.mobile from issued inner join books on books.acc_no = issued.acc_no inner join user on user.user_id = issued.user_id where tentative_return_dt = date(date_add(now(), interval 1 day)) `;

    db.query(sql, (err, rows) => {
      if (err) throw err;

      if (!rows.length) {
        callback({
          success: true
        });
      }

      rows.forEach(item => {
        const to = item.mobile;
        const msg =
          'Book Due Reminder - The book "' +
          trim(item.title) +
          '" issued to you is due for return at the library tomorrow';

        // send sms
        if (to && msg) {
          var request = require("request");
          const url = "http://login.smsmoon.com/API/sms.php";
          const body = {
            username: "raghuedu",
            password: "abcd.1234",
            from: "RAGHUT",
            to: to,
            msg: msg,
            type: "1",
            dnd_check: "0"
          };

          request.post(
            url,
            {
              form: body
            },
            function(error, response, body) {
              if (!error && response.statusCode == 200) {
                callback({
                  success: true,
                  data: body
                });
              }
            }
          );
        } else {
          callback({
            success: false,
            error: "sending sms failed"
          });
        }
      });
    });
  },

  // Admin dashboard
  admin_dashboard: function(data, callback) {
    const sql = `select count(books.book_id) as books_count,
(select count(issued.status) as issued_count from issued where status = 'issued') issued_ct,
(select count(issued.status) as reserved_count from issued where status = 'reserved') reserved_ct,
(select count(issued.status) as due_count from issued where status = 'issued' and datediff(now(), issue_dt) > 14) due_ct
from books`;
    db.query(sql, (err, rows) => {
      if (err) throw err;
      if (rows.length) {
        callback({
          success: true,
          data: rows
        });
      }
    });
  },

  user_dashboard: function(data, callback) {
    let user_id=data["user_id"];
    const sql = `select count(books.book_id) as books_count,
(select count(issued.status) as issued_count from issued where status = 'issued' and user_id='${user_id}') issued_ct,
(select count(issued.status) as reserved_count from issued where status = 'reserved' and user_id='${user_id}') reserved_ct,
(select count(issued.status) as due_count from issued where status = 'issued' and user_id='${user_id}' and datediff(now(), issue_dt) > 14) due_ct
 from books`;
    db.query(sql, (err, rows) => {
      if (err) throw err;
      if (rows.length) {
        callback({
          success: true,
          data: rows
        });
      }
    });
  },

  bookdetails: function(data, callback) {
    const sql = `select * from books where status='show'`;
    db.query(sql, (err, result) => {
      if (err) throw err;
      if (result.length) {
        callback({
          success: true,
          data: result
        });
      }
    });
  },

  requiest: function(data, callback) {
    const sql = `SELECT * FROM book_reserve`;
    db.query(sql, (err, result) => {
      if(err) throw err;
      if(result.length){
        callback({
          success: true,
          data: result
        });
      }
    })
  },

  addnewbook: function(data, callback) {
    let acc_no = data["acc_no"];
	  let call_no = data["call_no"];
	  let title = data["title"];
	  let author = data["author"];				
	  let publisher = data["publisher"];
	  let category = data["category"];
	  let edition = data["edition"];
	  let volume = data["volume"];
	  let vendor = data["vendor"];
	  let bill_dt = data["bill_dt"];
	  let price = data["price"];
	  let entry_dt = data["entry_dt"];
    const sql = `INSERT INTO books(acc_no,call_no,title,author,publisher,category,edition,volume,vendor,bill_dt,price,entry_dt) values('${acc_no}', '${call_no}', '${title}', '${author}', '${publisher}', '${category}', '${edition}', '${volume}', '${vendor}', '${bill_dt}', '${price}', '${entry_dt}')`;

     db.query(sql, (err, results) => {
      if (err) {
        callback({
          success: false,
          error: err.message
        })
        return;
      }
      if (results.insertId) {
        callback({
          success: true,
          id: results.insertId
        });
      } else {
        callback({
          success: false,
          error: error.message
        });
      }
    });
  },

  edit: function(data, callback) {
    let id = data["id"];
    const sql = `select * from books where book_id='${id}'`;
    db.query(sql, (err, result) => {
      if (err) throw err;
      if (result.length) {
        callback({
          success: true,
          data: result
        });
      }
    });
  },

  delete: function(data, callback) {
    let id = data["id"];
    const sql = `UPDATE books SET status='hide' WHERE book_id='${id}'`;
    db.query(sql, (err, result) => {
      if (err) throw err;
      if (result.length) {
        callback({
          success: true,
          data: result
        });
      }
    });
  },

  requestdelete: function(data, callback) {
    let id = data["id"];
    const sql = `delete from issued where issue_id='${id}'`;
    db.query(sql, (err, result) => {
      if (err) throw err;
      if (result.length) {
        callback({
          success: true,
          data: result
        });
      }
    });
  },

  update: function(data, callback) {
    let acc_no = data["acc_no"];
	  let call_no = data["call_no"];
	  let title = data["title"];
	  let author = data["author"];				
	  let publisher = data["publisher"];
	  let category = data["category"];
	  let edition = data["edition"];
	  let volume = data["volume"];
	  let vendor = data["vendor"];
	  let bill_dt = data["bill_dt"];
	  let price = data["price"];
	  let entry_dt = data["entry_dt"];
    let book_id = data["book_id"];
    
    const sql = `update books set acc_no='${acc_no}',call_no='${call_no}',title='${title}',author='${author}',publisher='${publisher}',category='${category}',edition='${edition}',volume='${volume}',vendor='${vendor}',bill_dt='${bill_dt}',price='${price}',entry_dt='${entry_dt}' WHERE book_id='${book_id}'`;
    db.query(sql, (err, result) => {
      if (err) throw err;
      if (result.length) {
        callback({
          success: true,
          data: result
        });
      }
    });
  },

  check_book: function (data, callback) {
    let acc_no = data["acc_no"];

   const sql = `select * from books where acc_no = '${acc_no}'`;
    console.log(sql);

   db.query(sql, (err, rows) => {
      if (err) throw err;
      if (rows.length) {
        callback({
          success: true,
          data: rows
        });
      }
    });
  },
  bookid: function (data, callback) {

   //  const result1 = [id=>'',text=>''];
    //   const result = [`select acc_no as id, CONCAT(acc_no, '-', title ,'-',category) as text from books`];
    //   let sql = result1.concat(result);
    // let sql = Array.prototype.push.apply(result1, result);
    let sql = `select acc_no as id, CONCAT(acc_no, ' - ', title, ' - ', author,' - ',category) as text from books`;
    console.log(sql);

   db.query(sql, (err, rows) => {
      if (err) throw err;
      if (rows.length) {
        callback({
          success: true,
          data: rows

       });
        console.log(data, 'testing');
      }
    });
  },

  reservebook: function (data, callback) {

   let title = data['title'];
    let author = data['author'];
    let edition = data['edition'];
    let volume = data['volume'];
    let publisher = data['publisher'];
    let name = data['name'];
    let reg_no = data['reg_no'];
    let user_id = data['user_id'];

   let sql = `insert into book_reserve(title, author, edition, volume, publisher, name, reg_no, user_id) values('${title}', '${author}', '${edition}', '${volume}', '${publisher}', '${name}', '${reg_no}', '${user_id}');`;

   console.log(sql);

   db.query(sql, (err, results) => {
      if (err) {
        callback({
          success: false,
          error: err.message
        })
        return;
      }
      if (results.insertId) {
        callback({
          success: true,
          id: results.insertId
        });
      } else {
        callback({
          success: false,
          error: error.message
        });
      }
    });
  },

  fine: function(data, callback) {
    let fine = data["fine"];
    let date = data["date"];
   // const sql = `SELECT SUM(fine) FROM issued WHERE issue_dt BETWEEN '${fine}' AND '${date}'`;
    const sql = `SELECT SUM(fine) FROM issued`;
    db.query(sql, (err, result) => {
      if (err) throw err;
      if (result.length) {
        callback({
          success: true,
          data: result
        });
      }
    });
  },
    


    
};

module.exports = Book;
