const winston = require('winston');
require('dotenv').config();

winston.configure({
    transports: [
        new(winston.transports.Console)({
            level: 'info'
        }),
        new(winston.transports.File)({
            name: 'error-file',
            filename: process.env.LOG_FOLDER + '/log.log',
            level: 'error'
        })

    ]
});

// error,
// warn,
// info,
// verbose,
// debug,
// and silly.

// winston.log('info', 'Hello log files!', {  
//   someKey: 'some-value'
// })

module.exports = winston;