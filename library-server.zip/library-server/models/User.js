var jwt = require('jsonwebtoken');
var config = require('../config');
var generator = require('generate-password');
var md5 = require('md5') //, sha1 = require('sha1');
// var salt = 'd2g6IOP(U(&Â§)%UÂ§VUIPU(HN%V/Â§Â§URerjh0Ã¼rfqw4zoÃ¶qe54gÃŸ0Ã¤Q"LOU$3wer';

var db = require('../db');

var User = {
    // Login
    login: function (data, callback) {
        let reg_no = data['reg_no'];
        let password = md5(data['password']);
        const sql = `select * from user where reg_no = '${reg_no}' and password = '${password}' limit 1`;

        db.query(sql, (err, rows) => {
            if (err) {
                callback({
                    success: false,
                    err: err.message
                });
                return;
            }
            if (rows.length == 1) {
                let user = rows[0];

                // create token
                var token = jwt.sign(user, config.secret, {
                    expiresIn: "24h" // expires in 24 hours
                });

                callback({
                    success: true,
                    data: user,
                    token: token
                });
            } else {
                callback({
                    success: false,
                    error: 'Incorrect Password'
                });
            }
        });
    },

    // Registration and update profile/password
    register: function (data, callback) {
        data.password = md5(data.password);
        if (data.new_password) {
            data.new_password = md5(data.new_password);
        }

        let user_id = data['user_id'];
        let name = data['name'];
        let user_type = data['user_type'];
        let reg_no = data['reg_no'];
        let email = data['email'];
        let mobile = data['mobile'];
        let password = data['password'];
        let new_password = data['new_password'];

        // registration
        if (!user_id) {
            let error = 'Registration failed';

            let sql = `insert into user(name, user_type, reg_no, email, mobile, password) values('${name}', '${user_type}', '${reg_no}', '${email}', '${mobile}', '${password}');`;

            db.query(sql, (err, results) => {
                if (err) {
                    callback({
                        success: false,
                        error: err.message
                    })
                    return;
                }

                if (results.insertId) {
                    callback({
                        success: true,
                        id: results.insertId
                    });
                } else {
                    callback({
                        success: false,
                        error: error.message
                    });
                }
            });
        } else {
            let error = 'Profile update failed';

            // update profile
            let sql = `update user set name = '${name}', mobile = '${mobile}' where user_id = ${user_id} limit 1`;
            if (new_password != '') {
                sql = `update user set `;
                if (name && mobile) {
                    sql += ` name = '${name}', mobile = '${mobile}', `;
                }
                sql += ` password = '${new_password}' where user_id = ${user_id} and password = '${password}' limit 1`;
            }

            console.log(sql);

            db.query(sql, (err, results) => {
                if (err) {
                    callback({
                        success: false,
                        error: err.message
                    })
                    return;
                }

                if (results.affectedRows) {
                    callback({
                        success: true,
                        id: results.affectedRows
                    });
                } else {
                    callback({
                        success: false,
                        error: error
                    });
                }
            });
        }
    },

    // Profile
    profile: function (data, callback) {
        const user_id = data['user_id'];
        const sql = `select * from user where user_id = '${user_id}' limit 1`;

        db.query(sql, (err, rows) => {
            if (err) {
                callback({
                    success: false,
                    error: err.message
                });
                return;
            }
            if (rows.length == 1) {
                callback({
                    success: true,
                    data: rows[0]
                });
            } else {
                callback({
                    success: false,
                    error: 'Authentication failed. User not found.'
                });
            }
        });
    },

    // Profile
    forget_password: function (data, callback) {
        const reg_no = data['reg_no'];
        const email = data['email'];

        const sql = `select mobile from user where reg_no = '${reg_no}' or email = '${email}' limit 1`;

        db.query(sql, (err, rows) => {
            if (err) throw err;
            if (rows.length == 1) {

                let new_password = generator.generate({
                    length: 5,
                    numbers: false
                });

                let hash = md5(new_password);

                const updateSql = `update user set password = '${hash}' where reg_no = '${reg_no}' limit 1`;
                db.query(updateSql, (err, results) => {
                    if (results.affectedRows) {
                        const to = rows[0].mobile;
                        const msg = 'Your new password at Library Management System is ' + new_password;

                        // send sms
                        if (to && msg) {
                            var request = require('request');
                            const url = "http://login.smsmoon.com/API/sms.php";
                            const body = {
                                'username': 'raghuedu',
                                'password': 'abcd.1234',
                                'from': 'RAGHUT',
                                'to': to,
                                'msg': msg,
                                'type': '1',
                                'dnd_check': '0'
                            };

                            request.post(url, {
                                form: body
                            }, function (error, response, body) {
                                if (!error && response.statusCode == 200) {
                                    console.log(body) // Print the google web page.
                                    callback({
                                        success: true,
                                        data: body
                                    });
                                }
                            });


                        } else {
                            callback({
                                success: false,
                                error: 'sending sms failed'
                            });
                        }
                    }
                });


            } else {
                callback({
                    success: false,
                    error: 'User not found.'
                });
            }
        });
    },




};



module.exports = User;