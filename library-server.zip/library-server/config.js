module.exports = {
    'secret': 'akriviaissueregisterlonglongloooonglonglongjsonwebtokensomerandomstring',
};
