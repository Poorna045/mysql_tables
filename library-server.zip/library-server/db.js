require('dotenv').config();
var mysql = require('mysql');

var connection = mysql.createPool({
    host: "localhost",
    user: "root",
    password: null,
    database: "empstore"
});

module.exports = connection;