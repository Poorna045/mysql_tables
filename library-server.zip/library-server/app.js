var express = require('express');
var path = require('path');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var compression = require('compression');

var user = require('./routes/users');
var book = require('./routes/books');
var authenticate = require('./routes/authenticate');
var cors = require('cors');

var app = express();
app.use(cors());
app.use(compression());

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false
}));


app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/login', user.login);
app.post('/api/register', user.register);
app.get('/api/cron_cancel_reservation', book.cron_cancel_reservation)
app.get('/api/cron_due_reminder', book.cron_due_reminder)
app.post('/api/forget_password', user.forget_password);

app.use(authenticate);
app.post('/api/search_books', book.search_books)
app.post('/api/reserve_book', book.reserve_book)
app.post('/api/my_books', book.my_books)
app.post('/api/cancel_reservation', book.cancel_reservation)
app.post('/api/issue_book', book.issue_book)
app.post('/api/return_book', book.return_book)
app.post('/api/profile', user.profile)
app.post('/api/update_profile', user.register);
app.post('/api/admin_dashboard', book.admin_dashboard);

app.post('/api/user_dashboard', book.user_dashboard);
app.post('/api/addnewbook',book.addnewbook);
app.post('/api/bookdetails',book.bookdetails);
app.post('/api/requiest',book.requiest);
app.post('/api/edit',book.edit);
app.post('/api/update', book.update);
app.post('/api/delete',book.delete);
app.post('/api/requestdelete',book.requestdelete);
app.post('/api/check',book.check_book);
app.post('/api/bookid',book.bookid);
app.post('/api/reservebook',book.reservebook);
app.post('/api/fine', book.fine);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handler
app.use(function (err, req, res) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});



module.exports = app;