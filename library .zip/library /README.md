# Build steps
* `ng build --environment=local` = to host it on local system
* `ng build --environment=localprod` = to host it on our local ubuntu server

* After build process is complete, copy all files in dist to the remote server. 
* update base href in index.html
* add .htaccess
* copy server to remote server/folder/server (eg: remote server/labs/server)
* update database settings in database.php
 
