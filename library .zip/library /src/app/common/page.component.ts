import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AppSettings } from '../app.settings';

@Component({
    selector: 'library-page',
    templateUrl: 'page.component.html'
})
export class PageComponent implements OnInit {

    pageType: string;           // dashboard, labs
    subPageType: string;

    constructor(private _route: ActivatedRoute) { }

    ngOnInit() {
        this.pageType = this._route.snapshot.url[0].path;
        console.log("page typeaaaa",this._route);
        
        if (this._route.snapshot.url[1])
            this.subPageType = this._route.snapshot.url[1].path;
        this._route.params.subscribe(params => {
        });
    }
}