import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppSettings } from '../app.settings';

@Component({
    selector: 'library-header',
    templateUrl: 'header.component.html',
    styles: ['.page-header .navbar .navbar-nav .dropdown-menu>li>a{font-size: 16px;}']
})
export class HeaderComponent implements OnInit {
    @Input() pageType: string;
    @Input() subPageType: string;
    name: string;
    roles = AppSettings.roles;
    currentRole = sessionStorage.getItem('role');
    pendingApprovalCount: number;

    constructor(private router: Router, 
    // private _bookingService: BookingService
    ) { }

    ngOnInit() {
        this.name = sessionStorage.getItem('name');
        console.log("page type abc: ", this.pageType);

    }
}
