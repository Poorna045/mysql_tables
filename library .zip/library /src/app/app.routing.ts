import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './_guards/auth.guard';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './login/register.component';
import { PageComponent } from './common/page.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AppSettings } from './app.settings';
import { UserComponent } from './user/user.component';
import { BooklistComponent } from './booklist/booklist.component';
import { NewbookreserveComponent } from './newbookreserve/newbookreserve.component';
import { HeaderComponent } from './common/header.component';
import { BookreserveComponent } from './bookreserve/bookreserve.component';



//Admin components 
import { IssuebooksComponent } from './issuebooks/issuebooks.component';
import { AddbooksComponent } from './addbooks/addbooks.component';
import { BookdetailsComponent } from './bookdetails/bookdetails.component';
import { RequestComponent } from './request/request.component';


const appRoutes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: 'register', component: RegisterComponent },
    { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard], data: { role: 'admin,user'  } },
    { path: 'user', component: UserComponent, canActivate: [AuthGuard] },
   
   // user paths
    { path: 'booklist', component: BooklistComponent, canActivate: [AuthGuard], data: { role: 'user'  }  },
    { path: 'newbookreserve', component: NewbookreserveComponent, canActivate: [AuthGuard], data: { role: 'user'  }  },
    { path: 'bookreserve', component: BookreserveComponent, canActivate: [AuthGuard], data: { role: 'user'  }  },
  
    //Admin 
    { path: 'issuebooks', component: IssuebooksComponent, canActivate: [AuthGuard], data: { role: 'admin'  } },
    { path: 'addingnewbook', component: AddbooksComponent, canActivate: [AuthGuard], data: { role: 'admin'  }  },
    { path: 'bookdetails', component: BookdetailsComponent, canActivate: [AuthGuard], data: { role: 'admin'  }  },
    { path: 'request', component: RequestComponent, canActivate: [AuthGuard], data: { role: 'admin'  }  },

    { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
    { path: '**', redirectTo: '/dashboard' }
];

export const routing = RouterModule.forRoot(appRoutes);

