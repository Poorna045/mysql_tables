﻿import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppSettings } from '../app.settings';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthenticationService {
    exampledata: any;
    data = [];
    details: any;
    public userLoggedIn = false;
    headers = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: this.headers });

    constructor(private http: Http) { }

    login(loginData) {

        return this.http.post(AppSettings.loginApi, JSON.stringify(loginData), this.options)
            .map((response: Response) => {
                const data = response.json();
                console.log(data);
                if (data.success) {
                    if (data && data.token) {
                        console.log("here");
                        console.log(data.data);
                        sessionStorage.setItem('currentUser', data.token);
                        sessionStorage.setItem('user_id', data.data.user_id);
                        sessionStorage.setItem('reg_no', data.data.reg_no);
                        sessionStorage.setItem('role', data.data.role);
                        sessionStorage.setItem('name', data.data.name);
                        sessionStorage.setItem('user_type', data.data.user_type);
                        this.userLoggedIn = true;
                        console.log(sessionStorage);
                    }
                }
                return data;
            });
    }

    logout() {
        sessionStorage.removeItem('currentUser');
    }

    register(username: string, password: string, reg_no: string, email: string, mobile: string, user_type: string) {
        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });

        return this.http.post(
            AppSettings.registerApi,
            JSON.stringify(
                {
                    username: username, password: password,
                    reg_no: reg_no, email: email, mobile: mobile, user_type: user_type
                }
            ), options)
            .map((response: Response) => {
                const data = response.json();
                return data;
            });
    }


    // new book component
    reservebook(title: string, author: string, edition: string, volume: string, publisher: string) {
        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });

        let token = sessionStorage.getItem('currentUser');
        let user_id = sessionStorage.getItem('user_id');
        let reg_no = sessionStorage.getItem('reg_no');
        let name = sessionStorage.getItem('name');

        console.log(token, 'token');
        confirm('Are you sure, you want to send request for new book');
        return this.http.post(
            AppSettings.reservebookApi,
            JSON.stringify(
                {
                    title: title, author: author, user_id: user_id, reg_no: reg_no, name: name,
                    edition: edition, volume: volume, publisher: publisher, token: token
                }
            ), options)
            .map((response: Response) => {
                const data = response.json();
                console.log(response, 'hello');
                return data;
            });
    }

    getwishlist(bookdata) {
        
        return this.http.post(AppSettings.wishlistApi, JSON.stringify(bookdata), this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    //admin component
     private extractData(response: Response) {
        let body = response.json();
        return body || {};
    }

    private handleError(error: Response): Observable<any> {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }
    
    postData(value: any) {
         return this.http.post(AppSettings.addbookApi, JSON.stringify(value), this.options)
            .map((response: Response) => {
                const data = response.json();
                return data;
            });
    }


    getBookdetails(bookdata) {
        
        return this.http.post(AppSettings.bookdetailsApi, JSON.stringify(bookdata), this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    getrequestes(bookdata) {
        
        return this.http.post(AppSettings.requiestApi, JSON.stringify(bookdata), this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    edit(model)
    {
        return this.http.post(AppSettings.editApi, JSON.stringify(model), this.options)
                        .map((response: Response)=>{
                            this.details=response.json();
                            return this.details;
                        });
    }
     
    update(value){
        return this.http.post(AppSettings.updateApi, JSON.stringify(value), this.options)
    					  .map((response: Response)=>{
                            this.details=response.json();
                            return this.details;
                        });
    }

    delete(model)
    {
        return this.http.post(AppSettings.deleteApi, JSON.stringify(model), this.options)
                        .map((response: Response)=>{
                            this.details=response.json();
                            return this.details;
                        });
    }
    myBooks(body) {
        return this.http.post(AppSettings.myBooksApi, body,
            this.options)

            .map(this.extractData,
            console.log(this.extractData),
            )
            .catch(this.handleError);
    }
}
