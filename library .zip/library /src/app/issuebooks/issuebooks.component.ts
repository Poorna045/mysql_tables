import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IssueBooksService } from './issuebooks.service';
@Component({
  selector: 'library-issuebooks',
  templateUrl: './issuebooks.component.html',
  styleUrls: ['./issuebooks.component.css']
})
export class IssuebooksComponent implements OnInit {
  model: any = {};
  reg_no: string = '';
  email: string = '';
  user_id: number;
  search_type = 'user';
  due_days = [];
  books = [];

  constructor(private router: Router,
    private _route: ActivatedRoute,
    private _issuebooksService: IssueBooksService, ) { }

  ngOnInit() {
    this.due_days = Array.from(Array(30).keys()).map(x => ++x)
    this.myBooks();
  }

  myBooks() {
    this.books = [];
    const body = {};
    if (this.search_type === 'user') {
      body['reg_no'] = this.model.reg_no;
      body['user_id'] = sessionStorage.getItem('user_id');
      body['token'] = sessionStorage.getItem('currentUser');
      body['search_type'] = this.search_type;
    }
    this._issuebooksService.myBooks(body)
      .subscribe(data => {
        if (data.success) {
          data.data.forEach(book => {
            if (book.status == 'reserved') {
              book['due_days'] = 14
            }
            this.books.push(book);
          });
        }
      });
  }

  changeStatus(book, status) {
    const body = { acc_no: book.acc_no, user_id: book.user_id, due_days: book.due_days, status: status };
    body['token'] = sessionStorage.getItem('currentUser');
    this._issuebooksService.changeStatus(body, status)
      .subscribe(data => {
        if (data.success) {
          this.myBooks();
        }
      });
    //}
  }



}
