import { Injectable } from '@angular/core';
import { Issuebooks } from './booking';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

import { AppSettings } from '../app.settings';

@Injectable()
export class IssueBooksService {
    headers = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: this.headers });

    constructor(private _http: Http) {
    }

    // get list of bookings made by the user

    myBooks(body) {
        return this._http.post(AppSettings.myBooksApi, body,
            this.options)

            .map(this.extractData,
            )
            .catch(this.handleError);
    }

    changeStatus(body, status) {
        let api = '';
        switch (status) {
            case 'issue': api = AppSettings.issueBookApi; break;
            case 'return': api = AppSettings.returnBookApi; break;
        }
        return this._http.post(api, body,
            this.headers)

            .map(this.extractData)
            .catch(this.handleError);
    }


    private extractData(response: Response) {
        const body = response.json();
        return body || {};
    }

    private handleError(error: Response): Observable<any> {
        return Observable.throw(error.json().error || 'Server error');
    }

    callApi(url: string, method: string, body: Object): Observable<any> {

        const headers = new Headers({ 'Content-Type': 'application/json' });
        const options = new RequestOptions({ headers: headers });
        switch (method) {
            case 'post':
                return this._http.post(url, body, options).map((response: Response) => response.json());
            case 'get':
                return this._http.get(url, options).map((response: Response) => response.json());
        }
    }
}
