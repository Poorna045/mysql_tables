export class Issuebooks {
    issue_id: number;
    bookTitle:string;
    author:string;
    call_no: number;
    acc_no: number;
    user_id: number;
    booking_dt: number;
    issue_dt: number;
    status: number;
    insert_dt: number;

}