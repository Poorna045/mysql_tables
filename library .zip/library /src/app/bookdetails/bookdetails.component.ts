import { Component, OnInit, AfterViewInit, ViewChildren, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';
import { FormGroup, FormBuilder, Validators, FormControlName } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { IMyDpOptions } from 'mydatepicker';

import { AuthenticationService } from '../_services/authentication.service';
import { DatePipe } from "@angular/common";
import { GenericValidator } from '../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/merge';
import { SpinnerComponent } from '../common/spinner.component';

@Component({
  selector: 'library-bookdetails',
  templateUrl: './bookdetails.component.html',
  styleUrls: ['./bookdetails.component.css']
})
export class BookdetailsComponent implements OnInit {
  errorMessage: string;
  error: boolean;
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];
  model: any = {};
  search_type = 'user';
  due_days = [];
  books = [];
  msg = false;
  addbookForm: FormGroup;
  displayMessage: { [key: string]: string } = {};
    private validationMessages: { [key: string]: { [key: string]: string } };
    private genericValidator: GenericValidator;

  print_data = {
    acc_no: '', entry_dt: '',
  }
  
  change: { id: string; };
  data: any;
  details: any;
  details1: any;
  edit_data = false;
  table_data = true;
  date: DateModel;
  options: DatePickerOptions;


  constructor(private serviceProvider: AuthenticationService,private fb: FormBuilder,
        private route: ActivatedRoute,
        private router: Router) {
           this.validationMessages = {
            title: {
                required: 'Title is required',
                maxLength: 'Title should be less than 255 characters'
            },
            author: {
                required: 'Author is required',
                maxLength: 'Author should be less than 255 characters'
            },
            acc_no: {
                required: 'Account number is required',
                maxLength: 'Account number should be less than 11 characters'
            },
            call_no: {
                required: 'Call number is required',
                maxLength: 'Call number should be less than 20 characters'
            },
            publisher: {
                required: 'Publisher name is required',
                maxLength: 'Publisher name should be less than 255 characters'
            },
            category: {
                required: 'Book Category is required',
                maxLength: 'Category name should be less than 100 characters'
            },
            edition: {
                required: 'Book Edition is required',
                maxLength: 'Edition name should be less than 10 characters'
            },
            volume: {
                required: 'Volume name is required',
                maxLength: 'Volume should be less than 10 characters'
            },
            vendor: {
                required: 'Vendor name is required',
                maxLength: 'Vendor should be less than 255 characters'
            },
            bill_no: {
                required: 'Bill number is required',
                maxLength: 'Bill Date should be less than 100 characters'
            },
            bill_dt: {
                required: 'Bill Date is required'
            },
            price: {
                required: 'Price is required'
            },
            entry_dt: {
                required: 'Entry Date is required'
            }
        };
         }
  //  public data;
  public filterQuery = "";
  public filterQuery1 = "";
  public rowsOnPage = 10;
  public sortBy = "email";
  public sortOrder = "asc";

  public toInt(num: string) {
    return +num;
  }

  public sortByWordLength = (a: any) => {
    return a.city.length;
  }

  ngOnInit() { 
    this.genericValidator = new GenericValidator(this.validationMessages);
        this.addbookForm = this.fb.group({
            'title': ['', [Validators.required, Validators.maxLength(255)]],
            'author': ['', [Validators.required, Validators.maxLength(255)]],
            'acc_no': ['', [Validators.required, Validators.maxLength(11)]],
            'call_no': ['', [Validators.required, Validators.maxLength(20)]],
            'publisher': ['', [Validators.required, Validators.maxLength(255)]],
            'category': ['', [Validators.required, Validators.maxLength(100)]],
            'edition': ['', [Validators.required, Validators.maxLength(10)]],
            'volume': ['', [Validators.required, Validators.maxLength(10)]],
            'vendor': ['', [Validators.required, Validators.maxLength(255)]],
            'bill_no': ['', [Validators.required, Validators.maxLength(100)]],
            'bill_dt': ['', Validators.required],
            'price': ['', [Validators.required, Validators.maxLength(255)]],
            'entry_dt': ['', Validators.required],
            'user_type': [{ value: 'admin', disabled: false }, [Validators.required]],
        });
  }

  ngAfterViewInit(): void {
        if (this.addbookForm) {
            const controlBlurs: Observable<any>[] = this.formInputElements
                .map((formControl: ElementRef) => Observable.fromEvent(formControl.nativeElement, 'blur'));

            Observable.merge(this.addbookForm.valueChanges, ...controlBlurs).debounceTime(800).subscribe(value => {
                this.displayMessage = this.genericValidator.processMessages(this.addbookForm);
            });
        }
    }
  myBooks() {
    this.books = [];
    const body = {};
    body['title'] = this.model.title;
    body['token'] = sessionStorage.getItem('currentUser');
    this.serviceProvider.getBookdetails(body)
      .subscribe(response => {
        this.details1 = response.data;
      });
  }
  edit(id: string) {
    var getdata = {};
    getdata['user_id'] = sessionStorage.getItem('user_id');
    getdata['token'] = sessionStorage.getItem('currentUser')
    console.log(getdata,'getdata test');
    
    this.table_data = false;
    getdata['id'] = id;
    this.serviceProvider.edit(getdata)
      .subscribe(response => {
        this.print_data = response.data[0];
       this.addbookForm.patchValue(this.print_data);
      //  this.add(this.print_data);
        this.print_data.entry_dt = this.print_data.entry_dt;
        var date = new Date(this.print_data.entry_dt);
        var datePipe = new DatePipe('en-US');
        this.print_data.entry_dt = datePipe.transform(this.print_data.entry_dt, 'dd/MM/yyyy');
        if (response) {
          this.edit_data = true;
          this.table_data = false;
        }
      });
  }

  saveDate(field, date) {
    const dt = date;
    // const dt = date.getFullYear() + '-' +
    //   (('0' + (date.getMonth() + 1)).slice(-2)) + '-' +
    //   (('0' + date.getDate()).slice(-2));

    switch (field) {
      case 'entry_dt':
        this.addbookForm.patchValue({ entry_dt: dt });
        this.addbookForm.controls['entry_dt'].markAsDirty();
        break;
      case 'bill_dt':
        this.addbookForm.patchValue({ bill_dt: dt });
        this.addbookForm.controls['bill_dt'].markAsDirty();
        break;
    }
  }

  add() {
    console.log(this.addbookForm.controls['title'].value,'updated');
    const value = {
                acc_no: this.addbookForm.controls['acc_no'].value,
                call_no: this.addbookForm.controls['call_no'].value,
                title: this.addbookForm.controls['title'].value,
                author: this.addbookForm.controls['author'].value,
                publisher: this.addbookForm.controls['publisher'].value,
                category: this.addbookForm.controls['category'].value,
                edition: this.addbookForm.controls['edition'].value,
                volume: this.addbookForm.controls['volume'].value,
                vendor: this.addbookForm.controls['vendor'].value,
                bill_dt: this.addbookForm.controls['bill_dt'].value,
                bill_no: this.addbookForm.controls['bill_no'].value,
                price: this.addbookForm.controls['price'].value,
                entry_dt: this.addbookForm.controls['entry_dt'].value,
                user_id:sessionStorage.getItem('user_id'),
                token:sessionStorage.getItem('currentUser')
            }

            console.log('value is', value)

    this.serviceProvider.update(value)
    .subscribe(data => {
          this.myBooks();
      });
      // .subscribe(details1 => {
      //   this.serviceProvider.getBookdetails(value)
      //     .subscribe(response => {
      //       this.details1 = response.data;
      //       if (response) {
      //         this.msg = true;
      //         this.edit_data = false
      //         setTimeout(function () { this.msg = false; }.bind(this), 3000);
      //       }
      //     });
      // });
    this.table_data = true;
    this.edit_data = false;
  }

  // add(detail) {
  //   console.log(detail, 'function');
  //   this.error = false;
  //   this.errorMessage = '';

  //   const dashboardData = {};
  //   dashboardData['title'] = detail.title;
  //   dashboardData['author'] = detail.author;
  //   dashboardData['acc_no'] = detail.acc_no;
  //   dashboardData['user_id'] = sessionStorage.getItem('user_id');
  //   dashboardData['name'] = sessionStorage.getItem('name');
  //   dashboardData['user_type'] = sessionStorage.getItem('user_type');
  //   dashboardData['reg_no'] = sessionStorage.getItem('reg_no');
  //   dashboardData['token'] = sessionStorage.getItem('currentUser');

  //   this.serviceProvider.update(dashboardData)
  //     .subscribe(data => {
  //       // console.log(data,'success');
  //       if (data) {
  //         console.log(data, 'success');
  //         this.errorMessage = 'Your request is procceded successful.';
        
  //         if(data.error){
  //           localStorage.setItem('errormsg',data.error);
  //         }
  //         if(data.id){
  //         alert(this.errorMessage);
  //         }
  //         this.router.navigate([this.returnUrl]);
  //       }

  //       else {
  //         this.error = true;
  //         this.errorMessage = 'Please reserve the book';
  //       }
        
  //     });
  // }

  cancel() {
    this.table_data = true;
    this.edit_data = false;
  }

  delete(id: string) {
    if (confirm('Are you sure, you want to delete the book')) {
      const deletedate = {};
      deletedate['token'] = sessionStorage.getItem('currentUser');
      deletedate['id'] = id;
      deletedate['title'] = '';
      this.serviceProvider.delete(deletedate)
        .subscribe(data => {
          if (data.success) {
            this.serviceProvider.getBookdetails(deletedate)
              .subscribe(response => {
                this.details1 = response.data;
              });
          }
        });
    }
  }

}
