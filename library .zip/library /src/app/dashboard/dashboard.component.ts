import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DashboardService } from './dashboard.service';
import { SpinnerComponent } from '../common/spinner.component';

@Component({
    selector: 'library-dashboard',
    templateUrl: './dashboard.component.html',
    styles: [`.dashboard-stat2.borderedblue {
    border: 1px solid #168de2;
    background-color: #168de2;
    color:#fff;
    cursor:pointer;
} .dashboard-stat2.borderedred{
    border: 1px solid #004a77;
    background-color: #004a77;
     color:#fff;
}
.dashboard-stat2.borderedgreen {
    border: 1px solid #142736;
    background-color: #142736;
     color:#fff;
     cursor:pointer;
}
.dashboard-stat2.borderedpurple {
    border: 1px solid #0087b4;
    background-color: #0087b4;
     color:#fff;
     cursor:pointer;
}`]
})
export class DashboardComponent implements OnInit {
    headerpageType: string;
    subPageType: string;
    // isRequesting = false;
    role = sessionStorage.getItem('role');
    routerLink = "";
    books_count: number;
    issued_ct: number;
    reserved_ct: number;
    due_ct: number;
    dashboardLink = '/booklist';
    dashboardLinks = '/bookloan';
    dashboardLink1 = '/issuebooks';

    constructor(private _router: Router,
        private _route: ActivatedRoute,
        private _dashboardService: DashboardService) { }

    ngOnInit() {
        this.getDashboard();
    }
    getDashboard() {
        const dashboardData = {};
        dashboardData['user_id'] = sessionStorage.getItem('user_id');
        dashboardData['token'] = sessionStorage.getItem('currentUser');
        if (this.role == 'user') {
            this._dashboardService.getDashboardUser(dashboardData).subscribe(data => {
                let temp = data.data[0];
                this.books_count = temp.books_count;
                this.issued_ct = temp.issued_ct;
                this.reserved_ct = temp.reserved_ct;
                this.due_ct = temp.due_ct;
            });
        } else {
            this._dashboardService.getDashboard(dashboardData).subscribe(data => {
                let temp = data.data[0];

                this.books_count = temp.books_count;
                this.issued_ct = temp.issued_ct;
                this.reserved_ct = temp.reserved_ct;
                this.due_ct = temp.due_ct;
            });
        }

    }


}
