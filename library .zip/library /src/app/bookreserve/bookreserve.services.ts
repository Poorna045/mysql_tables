import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

import { AppSettings } from '../app.settings';

@Injectable()
export class BookreserveService {
    headers = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: this.headers });

    constructor(private _http: Http) {
    }

    // get list of bookings made by the user

    myBooks(body) {
        console.log(body, 'data entered');
        return this._http.post(AppSettings.myBookApi, body,
            this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    getreserve(bodyData) {
        console.log(bodyData, 'bodydata entered');
        return this._http.post(AppSettings.reserveBooksApi, bodyData,
            this.options)
            .map(this.extractData)
            .catch(this.handleError);
    }

    private extractData(response: Response) {
        const body = response.json();
        return body || {};
    }

    private handleError(error: Response): Observable<any> {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}
