import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { BookreserveService } from '../bookreserve/bookreserve.services'

@Component({
  selector: 'library-bookreserve',
  templateUrl: './bookreserve.component.html',
  styleUrls: ['./bookreserve.component.css']
})
export class BookreserveComponent implements OnInit {
    value: string;
  details = [];
  books = [];
  searchTerm = '';
  searchControl: FormControl;
  search_type = 'user';
  error = false;
  errorMessage = '';
  returnUrl: string;
  count = sessionStorage.getItem('role');


  constructor(private router: Router,
    private _route: ActivatedRoute,
    private bookreserveService: BookreserveService, ) { }

  ngOnInit() {
    this.returnUrl = this._route.snapshot.queryParams['returnUrl'] || '/booklist';
  }

  getBook() {
    this.books = [];

    const body = {}
    if (this.search_type === 'user') {
      body['search_term'] = this.searchTerm;
      body['user_id'] = sessionStorage.getItem('user_id');
      body['token'] = sessionStorage.getItem('currentUser');
      body['search_type'] = this.search_type;
    }

    this.bookreserveService.myBooks(body)

      .subscribe(data => {
        if (data.success) {
          this.books = data.data;
        }
      });

  }

  reserveBook(book) {
    this.error = false;
    this.errorMessage = '';
    const bodyData = {};
    bodyData['title'] = book.title;
    bodyData['author'] = book.author;
    bodyData['acc_no'] = book.acc_no;
    bodyData['user_id'] = sessionStorage.getItem('user_id');
    bodyData['name'] = sessionStorage.getItem('name');
    bodyData['user_type'] = sessionStorage.getItem('user_type');
    bodyData['reg_no'] = sessionStorage.getItem('reg_no');
    bodyData['token'] = sessionStorage.getItem('currentUser');

    this.bookreserveService.getreserve(bodyData)
      .subscribe(data => {
        
        if(this.count=='user'){
          data.count=data.count+1;
          this.value='5';
        }
        else{
          data.count=data.count+1;
          this.value='3';
        }

        if (data) {
          this.errorMessage = 'You reserved '+ (data.count)+' out of '+(this.value)+' books';

          if (data.error) {
            localStorage.setItem('errormsg', data.error);
          }
          if (data.id) {
            console.log(this.count,this.value);
            
            alert(this.errorMessage);
          }
          this.router.navigate([this.returnUrl]);
        }
        else {
          this.error = true;
          this.errorMessage = 'Please reserve the book';
        }

      });
  }

}
