import { Component, OnInit, AfterViewInit, ViewChildren, ElementRef } from '@angular/core';
import { AuthenticationService } from '../_services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControlName } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { IMyDpOptions } from 'mydatepicker';
import { DatePickerOptions, DateModel } from 'ng2-datepicker';


import { GenericValidator } from '../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/merge';
import { SpinnerComponent } from '../common/spinner.component';



@Component({
    selector: 'library-addbooks',
    templateUrl: './addbooks.component.html',
    styleUrls: ['./addbooks.component.css']
})
export class AddbooksComponent {
        entrydate_test= false;
    readOnly?: boolean;
    @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];

    addbookForm: FormGroup;
    error = false;
    errorMessage = '';
    isRequesting = false;
    buttonClicked = false;
    displayMessage: { [key: string]: string } = {};
    private validationMessages: { [key: string]: { [key: string]: string } };
    private genericValidator: GenericValidator;

    add_book: boolean;
    books: string;
    date: DateModel;
    options: DatePickerOptions;
     



    constructor(
        private serviceProvider: AuthenticationService,
        private fb: FormBuilder,
        private route: ActivatedRoute,
        private router: Router) {

        this.validationMessages = {
            title: {
                required: 'Title is required',
                maxLength: 'Title should be less than 255 characters'
            },
            author: {
                required: 'Author is required',
                maxLength: 'Author should be less than 255 characters'
            },
            acc_no: {
                required: 'Account number is required',
                maxLength: 'Account number should be less than 11 characters'
            },
            call_no: {
                required: 'Call number is required',
                maxLength: 'Call number should be less than 20 characters'
            },
            publisher: {
                required: 'Publisher name is required',
                maxLength: 'Publisher name should be less than 255 characters'
            },
            category: {
                required: 'Book Category is required',
                maxLength: 'Category name should be less than 100 characters'
            },
            edition: {
                required: 'Book Edition is required',
                maxLength: 'Edition name should be less than 10 characters'
            },
            volume: {
                required: 'Volume name is required',
                maxLength: 'Volume should be less than 10 characters'
            },
            vendor: {
                required: 'Vendor name is required',
                maxLength: 'Vendor should be less than 255 characters'
            },
            bill_no: {
                required: 'Bill number is required',
                maxLength: 'Bill Date should be less than 100 characters'
            },
            bill_dt: {
                required: 'Bill Date is required'
            },
            price: {
                required: 'Price is required'
            },
            entry_dt: {
                required: 'Entry Date is required'
            }
        };
        this.options = new DatePickerOptions();
    }

    ngOnInit() {
        this.genericValidator = new GenericValidator(this.validationMessages);
        this.addbookForm = this.fb.group({
            'title': ['', [Validators.required, Validators.maxLength(255)]],
            'author': ['', [Validators.required, Validators.maxLength(255)]],
            'acc_no': ['', [Validators.required, Validators.maxLength(11)]],
            'call_no': ['', [Validators.required, Validators.maxLength(20)]],
            'publisher': ['', [Validators.required, Validators.maxLength(255)]],
            'category': ['', [Validators.required, Validators.maxLength(100)]],
            'edition': ['', [Validators.required, Validators.maxLength(10)]],
            'volume': ['', [Validators.required, Validators.maxLength(10)]],
            'vendor': ['', [Validators.required, Validators.maxLength(255)]],
            'bill_no': ['', [Validators.required, Validators.maxLength(100)]],
            'bill_dt': ['', Validators.required],
            'price': ['', [Validators.required, Validators.maxLength(255)]],
            'entry_dt': ['', Validators.required],
            'user_type': [{ value: 'admin', disabled: false }, [Validators.required]],
        });
    }

    ngAfterViewInit(): void {
        if (this.addbookForm) {
            const controlBlurs: Observable<any>[] = this.formInputElements
                .map((formControl: ElementRef) => Observable.fromEvent(formControl.nativeElement, 'blur'));

            Observable.merge(this.addbookForm.valueChanges, ...controlBlurs).debounceTime(800).subscribe(value => {
                this.displayMessage = this.genericValidator.processMessages(this.addbookForm);
            });
        }
    }

    add() {
        this.error = false;
        this.errorMessage = '';
        this.buttonClicked = true;
        this.addbookForm.controls['user_type'].enable();

        if (this.addbookForm.valid) {
            this.isRequesting = true;
            const value = {
                acc_no: this.addbookForm.controls['acc_no'].value,
                call_no: this.addbookForm.controls['call_no'].value,
                title: this.addbookForm.controls['title'].value,
                author: this.addbookForm.controls['author'].value,
                publisher: this.addbookForm.controls['publisher'].value,
                category: this.addbookForm.controls['category'].value,
                edition: this.addbookForm.controls['edition'].value,
                volume: this.addbookForm.controls['volume'].value,
                vendor: this.addbookForm.controls['vendor'].value,
                bill_dt: this.addbookForm.controls['bill_dt'].value,
                bill_no: this.addbookForm.controls['bill_no'].value,
                price: this.addbookForm.controls['price'].value,
                entry_dt: this.addbookForm.controls['entry_dt'].value,
            }
            value['user_id'] = sessionStorage.getItem('user_id');
            value['token'] = sessionStorage.getItem('currentUser')
            this.serviceProvider.postData(value)
                .subscribe(response => {
                    console.log(response, 'response');

                    if (response.success == true) {
                        alert("Data Entered");
                        this.isRequesting = false;
                        this.router.navigateByUrl('/bookdetails');
                        this.addbookForm.reset();
                    }
                    else {
                        alert('Duplicate entry for Account number');
                        this.error = true;
                        this.isRequesting = false;
                        this.buttonClicked = false;
                    }
                });
        } else {
            this.error = true;
            this.isRequesting = true;
            this.buttonClicked = true;
            this.errorMessage = 'Books details are not inserted properly';
        }
    }

    saveDate(field, date) {
    this.entrydate_test = true;
    const dt = date;
    // const dt = date.getFullYear() + '-' +
    //   (('0' + (date.getMonth() + 1)).slice(-2)) + '-' +
    //   (('0' + date.getDate()).slice(-2));

    switch (field) {
      case 'entry_dt':
        this.addbookForm.patchValue({ entry_dt: dt });
        this.addbookForm.controls['entry_dt'].markAsDirty();
        break;
      case 'bill_dt':
        this.addbookForm.patchValue({ bill_dt: dt });
        this.addbookForm.controls['bill_dt'].markAsDirty();
        break;
    }
  }

    setDate(): void {
        let date = new Date();
        this.addbookForm.setValue({
            myDate: {
                date: {
                    year: date.getFullYear(),
                    month: date.getMonth() + 1,
                    day: date.getDate()
                }
            }
        });
    }

    clearDate(): void {
        this.addbookForm.setValue({ myDate: null });
    }
    entrydate(){
        this.entrydate_test = true;
    }
}
