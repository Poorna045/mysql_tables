import { Component } from '@angular/core';

@Component({
  selector: 'library-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'labs works!';
}
