import { Component, OnInit, AfterViewInit, ViewChildren, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControlName } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { AuthenticationService } from '../_services/authentication.service';

import { GenericValidator } from '../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/merge';
import { SpinnerComponent } from '../common/spinner.component';

@Component({
    selector: 'library-register',
    templateUrl: 'register.component.html',
    styleUrls: ['login.component.css']
})
export class RegisterComponent implements OnInit {
    @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];

    registerForm: FormGroup;
    error = false;
    errorMessage = '';
    isRequesting = false;
    buttonClicked = false;
    displayMessage: { [key: string]: string } = {};
    private validationMessages: { [key: string]: { [key: string]: string } };
    private genericValidator: GenericValidator;


    constructor(
        private fb: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService
    ) {
        this.validationMessages = {
            username: {
                required: 'Username is required',
                maxLength: 'Username should be less than 255 characters'
            },
            password: {
                required: 'Password is required',
                maxLength: 'Password should be less than 255 characters'
            },
            // fullname: {
            //     required: 'Full name is required',
            //     maxLength: 'Name should be less than 255 characters'
            // },
            reg_no: {
                required: 'Registration number is required',
                maxLength: 'Registration number should be less than 10 characters'
            },

            email: {
                email: 'Email is required',

            },
            mobile: {
                required: 'Mobile number is required',
                maxLength: 'Mobile number should be less than 10 characters'
            },
            //   user_type: {
            //     required: 'User Type is required',

            // }
        };
    }

    ngOnInit() {
        console.log('init');
        this.genericValidator = new GenericValidator(this.validationMessages);
        this.registerForm = this.fb.group({
            // 'fullname': ['', [Validators.required, Validators.maxLength(255)]],
            'username': ['bhas', [Validators.required, Validators.maxLength(255)]],
            'reg_no': ['bhas123', Validators.required],
            'password': ['1234', [Validators.required, Validators.maxLength(255)]],
            'email': ['bhas@bhas.com', [Validators.required, CustomValidators.email]],
            'mobile': ['9123412345', [Validators.required, Validators.maxLength(10)]],
            'user_type': [{ value: 'student', disabled: false }, [Validators.required]],
        });

        this.registerForm.controls['user_type'].valueChanges.subscribe(condition => {

            this.registerForm.controls['reg_no'].clearValidators();
            this.registerForm.controls['reg_no'].updateValueAndValidity();

            if (condition === 'student') {
                this.registerForm.controls['reg_no'].setValidators([Validators.required]);
                this.registerForm.controls['reg_no'].updateValueAndValidity();
            }
        });

    }


    ngAfterViewInit(): void {
        if (this.registerForm) {
            const controlBlurs: Observable<any>[] = this.formInputElements
                .map((formControl: ElementRef) => Observable.fromEvent(formControl.nativeElement, 'blur'));

            Observable.merge(this.registerForm.valueChanges, ...controlBlurs).debounceTime(800).subscribe(value => {
                 this.displayMessage = this.genericValidator.processMessages(this.registerForm);
            });
        }
    }


    save() {
        this.error = false;
        this.errorMessage = '';
        this.buttonClicked = true;
        this.registerForm.controls['user_type'].enable();

        if (this.registerForm.valid) {
            this.isRequesting = true;
            // this.registerForm.controls['user_type'].disable();
            this.authenticationService.register(
                this.registerForm.controls['username'].value,
                this.registerForm.controls['password'].value,
                this.registerForm.controls['reg_no'].value,
                this.registerForm.controls['email'].value,
                this.registerForm.controls['mobile'].value,
                this.registerForm.controls['user_type'].value)
                .subscribe(data => {

                    if (data.success) {
                        this.registerForm.reset();
                        this.errorMessage = 'Registration successful. <a href="/login">Click here</a> to Login';
                    } else {
                        this.error = true;
                        this.errorMessage = data.error;
                    }
                    this.isRequesting = false;
                    this.buttonClicked = false;
                });
        } else {
            this.error = true;
            this.errorMessage = 'Registration form not valid. Please make sure to enter all the fields';
        }
    }
}
