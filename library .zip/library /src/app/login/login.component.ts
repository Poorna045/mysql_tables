import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../_services/authentication.service';
import { UserService } from '../user/user.service';

@Component({
    selector: 'library-login',
    templateUrl: 'login.component.html',
    styleUrls: ['login.component.css']
})
export class LoginComponent implements OnInit {
    model: any = {};
    returnUrl: string;
    psw = false;
    error = false;
    login_user = true;
    errorMessage: string;
    success = false;
    successMessage: string;
    forget_email: string;
    user_type = 'student';

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private authenticationService: AuthenticationService,
        private userService: UserService
    ) { }

    ngOnInit() {
        this.error = false;
        this.authenticationService.userLoggedIn = false;
        // reset login status
        this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
    }

    login() {
        // creating object for login
        const loginData = {};
        loginData['reg_no'] = this.model.regnum;
        loginData['password'] = this.model.password;

        this.authenticationService.login(loginData)
            .subscribe(
            data => {
                // error logging in
                if (data && !data.success) {
                    this.error = true;
                    this.errorMessage = 'Incorrect username or password';
                } 
                     else {
                        this.error = false;
                        this.router.navigate([this.returnUrl]);
                    }
            },
            error => {
                // this.alertService.error(error);
            });
    }

    inputFocus() {
        if (this.error) {
            this.model.username = '';
            this.model.password = '';
            this.error = false;
        }
    }

    forgetPassword() {
        this.error = false;
        this.userService.forgetPassword(this.forget_email).subscribe(data => {
            if (data.success) {
                this.success = true;
                this.successMessage = 'New password has been generated and mailed to you';
            } else {
                this.error = true;
                this.errorMessage = data.error;
            }
            this.psw = false;
            this.login_user = true;
        });
    }

    password_forgot() {
        this.psw = true;
        this.login_user = false;
    }

    login_back() {
        this.forget_email = '';
        this.psw = false;
        this.login_user = true;
    }

}
