import { Component, OnInit, AfterViewInit, ViewChildren, ElementRef } from '@angular/core';
import { AuthenticationService } from '../_services/authentication.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControlName } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';

import { GenericValidator } from '../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/merge';
import { SpinnerComponent } from '../common/spinner.component';
@Component({
  selector: 'library-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {
    j: number;
    i: number;
    user_talbe =  false;
    admin_table = true;
  role: string;
  reg_no: any;
  details: any;
  returnUrl: any;
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];

  bookreserveform: FormGroup;
  error = false;
  errorMessage = '';
  isRequesting = false;
  buttonClicked = false;
  form_data = false;
  table_data = true;
  displayMessage: { [key: string]: string } = {};
  private validationMessages: { [key: string]: { [key: string]: string } };
  private genericValidator: GenericValidator;


  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    this.validationMessages = {
      title: {
        required: 'Book Name is required',
        maxLength: 'Book Name should be less than 255 characters'
      },
      author: {
        required: 'Author Name is required',
        maxLength: 'Author Name should be less than 255 characters'
      },
      edition: {
        required: 'Edition is required',
        maxLength: 'Edition should be less than 255 characters'
      },
      volume: {
        required: 'Book Volume is required',
        maxLength: 'Book Volume should be less than 100 characters'
      },
      publisher: {
        required: 'Publisher Name is required',
        maxLength: 'Publisher Name should be less than 255 characters'
      }
    };
    this.addedbook();
  }

  ngOnInit() {
    this.form_data = false;
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.bookreserveform = this.fb.group({
      'title': ['', [Validators.required, Validators.maxLength(255)]],
      'author': ['', [Validators.required, Validators.maxLength(255)]],
      'edition': ['', [Validators.required, Validators.maxLength(255)]],
      'volume': ['', [Validators.required, Validators.maxLength(100)]],
      'publisher': ['', [Validators.required, Validators.maxLength(255)]],
    });
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
  }


  ngAfterViewInit(): void {
    if (this.bookreserveform) {
      const controlBlurs: Observable<any>[] = this.formInputElements
        .map((formControl: ElementRef) => Observable.fromEvent(formControl.nativeElement, 'blur'));

      Observable.merge(this.bookreserveform.valueChanges, ...controlBlurs).debounceTime(800).subscribe(value => {
        this.displayMessage = this.genericValidator.processMessages(this.bookreserveform);
      });
    }
  }


  reserve() {
    this.error = false;
    this.errorMessage = '';
    this.buttonClicked = true;
    this.form_data = true;
    this.table_data = false;
    if (this.bookreserveform.valid) {
      this.isRequesting = true;
      this.authenticationService.reservebook(
        this.bookreserveform.controls['title'].value,
        this.bookreserveform.controls['author'].value,
        this.bookreserveform.controls['edition'].value,
        this.bookreserveform.controls['volume'].value,
        this.bookreserveform.controls['publisher'].value)
        .subscribe(data => {

          if (data.success) {
            this.bookreserveform.reset();
            this.errorMessage = 'Form successful Sent.';
            this.router.navigate([this.returnUrl]);
          } else {
            this.error = true;
            this.errorMessage = data.error;
          }
          this.isRequesting = false;
          this.buttonClicked = false;
        });
    } else {
      this.error = true;
      this.errorMessage = 'New Book Request form is not valid. Please make sure to enter all the fields';
    }
  }

  addedbook() {
    const dashboardData = {};
    this.form_data = false;
    this.table_data = true;
    dashboardData['user_id'] = sessionStorage.getItem('user_id');
    dashboardData['token'] = sessionStorage.getItem('currentUser')
    this.authenticationService.getrequestes(dashboardData)
      .subscribe(response => {
        this.reg_no = sessionStorage.getItem('reg_no');
        this.role = sessionStorage.getItem('role');
        this.i=1;
        this.j=1;
        this.details = response.data;
        console.log(this.details, 'details');
      });

  }

  newbookrequest() {
    this.form_data = true;
    this.table_data = false;
  }

  admintable(){
    this.admin_table = true;
    this.user_talbe = false;
  }
  
  usertable(){
    this.admin_table = false;
    this.user_talbe = true;
  }

}
