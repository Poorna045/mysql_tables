export interface User {
    user_id: number;
    name: string;
    email: string;
    mobile: string;
    current_password: string;
    new_password: string;
    confirm_password: string;
    user_type: string;
    role: string;
    reg_no: string;
}
