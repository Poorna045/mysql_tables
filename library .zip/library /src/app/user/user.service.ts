import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

import { AppSettings } from '../app.settings';
import { User } from './user';

@Injectable()
export class UserService {
    headers = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: this.headers });

    constructor(private _http: Http) {
    }

    getProfileData() {
        this.headers.append('token', sessionStorage.getItem('currentUser'));
        return this._http.post(AppSettings.profileDataApi,
            {
                user_id: sessionStorage.getItem('user_id'),
                token: sessionStorage.getItem('currentUser')

            }, this.options)
            .map(this.extractData)
            .do(data => console.log('getProfileData: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    editUser(user: User) {
        return this._http.post(AppSettings.editUserApi, user, this.options)
            .map(this.extractData)
            .do(data => console.log('editUser: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    forgetPassword(email) {
        return this._http.post(AppSettings.forgetPasswordApi, { email: email }, this.options)
            .map(this.extractData)
            .do(data => console.log('forgetPassword: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    private extractData(response: Response) {
        const body = response.json();
        return body || {};
    }

    private handleError(error: Response): Observable<any> {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}