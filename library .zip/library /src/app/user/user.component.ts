import { Component, OnInit, AfterViewInit, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName } from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { Router } from '@angular/router';

import { GenericValidator } from '../common/generic-validator';
import { UserService } from './user.service';
import { User } from './user';

@Component({
  selector: 'library-user',
  templateUrl: './user.component.html',
  styles: ['.user_table tr th { width:36%} .user_active{background: none; border-bottom: 4px solid #36c6d3; position: relative;}']
})
export class UserComponent implements OnInit, AfterViewInit {
  @ViewChildren(FormControlName, { read: ElementRef }) formInputElements: ElementRef[];
  userForm: FormGroup;
  user: User;

  // tabs
  currentTab = 1;

  // validation
  error = false;
  errorMessage = '';
  displayMessage: { [key: string]: string } = {};
  private validationMessages: { [key: string]: { [key: string]: string } };
  private genericValidator: GenericValidator;

  constructor(
    private _fb: FormBuilder,
    private _router: Router,
    private _userService: UserService
  ) {
    this.validationMessages = {
      name: {
        required: 'Please enter your Full Name'
      },
      mobile: {
        number: 'Mobile number is required'
      },
      email: {
        email: 'Email is required'
      },
      current_password: {
        required: 'Current Password is required'
      },
      reg_no: {
        required: 'Registration Number is required'
      },
      new_password: {
        required: 'New Password is required'
      },
      confirm_password: {
        equalTo: 'Passwords don\'t match'
      },
    };
  }

  ngOnInit() {
    console.log(sessionStorage);
    this.userForm = this._fb.group({
      user_id: [sessionStorage.getItem('user_id')],
      name: [{ value: sessionStorage.getItem('name') }],
      email: [sessionStorage.getItem('email')],
      mobile: [sessionStorage.getItem('mobile')],
      reg_no: [{ value: sessionStorage.getItem('reg_no'), disabled: true }],
      current_password: [''],
      new_password: [''],
      confirm_password: [''],
      user_type: [sessionStorage.getItem('user_type')],
      role: [sessionStorage.getItem('role')]
    });
    this.userForm.controls['user_type'].valueChanges.subscribe(condition => {

      this.userForm.controls['reg_no'].clearValidators();
      this.userForm.controls['reg_no'].updateValueAndValidity();

      if (condition === 'student') {
        this.userForm.controls['reg_no'].setValidators([Validators.required]);
        this.userForm.controls['reg_no'].updateValueAndValidity();
      }
    });

    this.getProfileData();

    this.genericValidator = new GenericValidator(this.validationMessages);
  }

  ngAfterViewInit(): void {
    if (this.userForm) {
      const controlBlurs: Observable<any>[] = this.formInputElements
        .map((formControl: ElementRef) => Observable.fromEvent(formControl.nativeElement, 'blur'));

      Observable.merge(this.userForm.valueChanges, ...controlBlurs).debounceTime(800).subscribe(value => {
        this.displayMessage = this.genericValidator.processMessages(this.userForm);
      });
    }
  }

  getProfileData() {
    this._userService.getProfileData().subscribe(data => {
      if (data.success) {
        this.user = data.data;
        console.log(data);
        // console.log('this user', this.user.name);
        this.userForm.patchValue({
          user_id: sessionStorage.getItem('user_id'),
          name: this.user.name,
          // fullname: this.user.fullname,
          reg_no: this.user.reg_no,
          email: this.user.email,
          mobile: this.user.mobile,
          user_type: this.user.user_type,
          role: this.user.role
        });
      }
    });
  }

  save() {

    Object.keys(this.userForm.controls).forEach(key => {
      if (!this.userForm.get(key).valid)
        console.log(key, " -> ", this.userForm.get(key).valid);
    });

    this.error = false;
    this.errorMessage = '';
    // this.userForm.controls['name'].enable();
    this.userForm.controls['reg_no'].enable();
    if (!this.userForm.valid) {
      this.error = true;
      this.errorMessage = 'Please enter all mandatory fields';
      // this.userForm.controls['name'].disable();
       this.userForm.controls['reg_no'].disable();
    }

    if (this.userForm.valid) {
      if (!this.userForm.dirty) {
        this.currentTab = 1;
      } else {
        const p = Object.assign({
          token: sessionStorage.getItem('currentUser'),
          user_id: sessionStorage.getItem('user_id')
        }, this.user, this.userForm.value, );
        this._userService.editUser(p)
          .subscribe(data => this.onSaveComplete(data),
          (error: any) => this.errorMessage = <any>error
          );
      }
    }
  }

  onSaveComplete(data): void {
    if (!data.success) {
      console.error('profile update failed');
      this.error = true;
      this.errorMessage = data.error;
    } else {
      console.error('profile update successful');
      this.user = this.userForm.value;
      console.log(this.user.name);

      sessionStorage.setItem('reg_no', this.user.reg_no);
      this.userForm.controls['reg_no'].disable();
      this.currentTab = 1;
    }
    this.userForm.patchValue({ current_password: '', new_password: '', confirm_password: '' });
  }

  cancel() {
    this.userForm.reset();
    this.currentTab = 1;
  }

  toggleTab(tabId) {
    switch (tabId) {
      case 1:
        this.currentTab = 1;
        console.log(this.currentTab);

        break;
      case 2:
        this.currentTab = 2;
        console.log(this.currentTab);
        this.userForm.get('current_password').clearValidators();
        this.userForm.get('new_password').clearValidators();
        this.userForm.get('confirm_password').clearValidators();
        this.userForm.get('current_password').updateValueAndValidity();
        this.userForm.get('new_password').updateValueAndValidity();
        this.userForm.get('confirm_password').updateValueAndValidity();

        this.userForm.get('mobile').setValidators([Validators.required, CustomValidators.number]);
        this.userForm.get('email').setValidators([Validators.required, CustomValidators.email]);
        this.userForm.get('reg_no').setValidators([Validators.required]);
        this.userForm.get('mobile').updateValueAndValidity();
        this.userForm.get('email').updateValueAndValidity();
        this.userForm.get('reg_no').updateValueAndValidity();
        break;

      case 3:
        this.currentTab = 3;
        console.log(this.currentTab);

        this.userForm.get('mobile').clearValidators();
        this.userForm.get('email').clearValidators();
        this.userForm.get('reg_no').clearValidators();

        this.userForm.get('mobile').updateValueAndValidity();
        this.userForm.get('email').updateValueAndValidity();
        this.userForm.get('reg_no').updateValueAndValidity();

        this.userForm.get('current_password').setValidators([Validators.required]);
        this.userForm.get('new_password').setValidators([Validators.required]);
        const new_password = this.userForm.get('new_password');
        this.userForm.get('confirm_password').setValidators(
          [CustomValidators.equalTo(new_password)]
        );
        this.userForm.get('current_password').updateValueAndValidity();
        this.userForm.get('new_password').updateValueAndValidity();
        this.userForm.get('confirm_password').updateValueAndValidity();
    }
  }
}
