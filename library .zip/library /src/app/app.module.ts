import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Select2Module } from 'ng2-select2';
import { DatePickerModule } from 'ng2-datepicker';
import { PaginationModule } from 'ng2-bootstrap/pagination';
import { CustomFormsModule } from 'ng2-validation';
import { DataTableModule } from "angular2-datatable";
import { DateValueAccessorModule } from 'angular-date-value-accessor';
import { IMyOptions, IMyDateModel, MyDatePickerModule } from 'mydatepicker';
import { routing } from './app.routing';
import { AppComponent } from './app.component';
import { PageComponent } from './common/page.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './login/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderComponent } from './common/header.component';
import { DateComponent } from './common/date.component';
import { AuthGuard } from './_guards/auth.guard';
import { AuthenticationService } from './_services/authentication.service';
import { UserComponent } from './user/user.component';
import { UserService } from './user/user.service';
import { SpinnerComponent } from './common/spinner.component';
import { DashboardService } from './dashboard/dashboard.service';
import { BooklistComponent } from './booklist/booklist.component';
import { BooklistService } from './booklist/booklist.services';
import { NewbookreserveComponent } from './newbookreserve/newbookreserve.component';
import { BookreserveComponent } from './bookreserve/bookreserve.component';
import { BookreserveService } from './bookreserve/bookreserve.services';
import { IssueBooksService } from './issuebooks/issuebooks.service';
import { IssuebooksComponent } from './issuebooks/issuebooks.component';
import { AddbooksComponent } from './addbooks/addbooks.component';
import { BookdetailsComponent } from './bookdetails/bookdetails.component';
import { RequestComponent } from './request/request.component';
import { DataFilterPipe } from "app/bookdetails/bookdetails.pipe";
import { DatePipe } from "@angular/common";


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    HeaderComponent,
    PageComponent,
    RegisterComponent,
    UserComponent,
    SpinnerComponent,
    BooklistComponent,
    NewbookreserveComponent,
    BookreserveComponent,
    IssuebooksComponent,
    DataFilterPipe,
    AddbooksComponent,
    BookdetailsComponent,
    RequestComponent,
    BooklistComponent,
    DateComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    Select2Module,
    DatePickerModule,
    routing,
    DataTableModule,
    DateValueAccessorModule,
    MyDatePickerModule
  ],
  providers: [
    AuthGuard,
    AuthenticationService,
    UserService,
    DashboardService,
    BooklistService,
    BookreserveService,
    IssueBooksService,
    DatePipe,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
