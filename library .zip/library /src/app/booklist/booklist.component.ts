import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'app/_services/authentication.service';
import { BooklistService } from '../booklist/booklist.services';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'library-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})

export class BooklistComponent implements OnInit {
  hhh: any;
  returnUrl: any;
  msg: boolean;
  details1: any;
  name: any;
  data = [];
  details = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private serviceProvider: AuthenticationService,
    private booklistservice: BooklistService) {

    const dashboardData = {};
    dashboardData['reg_no'] = sessionStorage.getItem('reg_no');
    dashboardData['user_id'] = sessionStorage.getItem('user_id');
    dashboardData['token'] = sessionStorage.getItem('currentUser')
    this.booklistservice.getBooklist(dashboardData).subscribe(response => {
      this.data = response.data;
    });
  }


  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
    if (localStorage.getItem('errormsg')) {
      var data = localStorage.getItem('errormsg');
      alert(data)
      localStorage.removeItem('errormsg');
    }
  }


  delete(acc_no) {
    if (confirm('Are you sure, you want to cancel the book Reservation')) {
      const deletedate = {};
      deletedate['user_id'] = sessionStorage.getItem('user_id');
      deletedate['token'] = sessionStorage.getItem('currentUser');
      deletedate['acc_no'] = acc_no;
      this.booklistservice.delete(deletedate)
        .subscribe(details => {
          this.details = details;
        });
      this.router.navigate([this.returnUrl]);
    }
  }

}

