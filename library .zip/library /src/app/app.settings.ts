import { environment } from '../environments/environment';

export class AppSettings {

    public static loginApi: string = 'http://192.168.0.101:8000/api/login';
    public static myBookApi: string = 'http://192.168.0.101:8000/api/search_books';
    public static reserveBooksApi: string = 'http://192.168.0.101:8000/api/reserveuserbook';
    
    public static dashboarduserApi: string = 'http://192.168.0.101:8000/api/user_dashboard';
    public static dashboardApi: string = 'http://192.168.0.101:8000/api/admin_dashboard';
    public static bookissuedApi: string = 'http://192.168.0.101:8000/api/my_books';
    public static reservebookApi: string = 'http://192.168.0.101:8000/api/newbook';
    public static bookdeleteApi: string = 'http://192.168.0.101:8000/api/cancel_reservation';

    public static registerApi: string = 'http://192.168.0.101:8000/api/register';
    public static forgetPasswordApi = environment.envUrl + '/server/api/forget_password';

    public static profileDataApi: string = 'http://192.168.0.101:8000/api/profile';
    public static editUserApi: string = 'http://192.168.0.101:8000/api/update_profile';

    public static addbookApi: string = 'http://192.168.0.101:8000/api/addnewbook';
    public static bookdetailsApi: string = 'http://192.168.0.101:8000/api/bookdetails';
    public static requiestApi: string = 'http://192.168.0.101:8000/api/requiest';
    public static wishlistApi: string = 'http://192.168.0.101:8000/api/wishlist';
    public static editApi: string = 'http://192.168.0.101:8000/api/edit';
    public static updateApi: string = 'http://192.168.0.101:8000/api/update';
    public static deleteApi: string = 'http://192.168.0.101:8000/api/delete';
    public static myBooksApi: string = 'http://192.168.0.101:8000/api/my_books';
    public static issueBookApi: string = 'http://192.168.0.101:8000/api/issue_book';
    public static returnBookApi: string = 'http://192.168.0.101:8000/api/return_book';

    // roles
    public static roles = {
        dashboard: ['admin', 'user'],
        issuebooks: ['admin'],
        addbooks: ['admin'],
        acceptreject: ['admin'],
        bookdetails: ['admin'],
        request: ['admin'],

        booklist: ['user'],
        bookreserve: ['user'],
        newbookreserve: ['user'],
    };
}

