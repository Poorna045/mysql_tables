export const environment = {
  production: true,
  envName: 'prod',
  envUrl: 'http://www.raghuenggcollege.com/labs'
  
};
